## Thank you for your contribution to Bloody-Buddy 🤩🤩 

[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE) ![Open Source Love](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)  ![PRs Welcome](https://img.shields.io/badge/PRs-welcome-green.svg)

**Please mention the following in order to get PR merged**  🙌🏻🙌🏻 
<!-- 1. E.g. Is it a new feature, bugfix, code improvement etc. ? Add some description. -->
<!-- 2. Mention the issue number using # -->
<!-- 3. Please add appropriate screenshots & GitHub page link to track the changes. -->


1. Kind of change this PR introduce :
2. Issue it resolves : 
3. GitHub Page Link : 
